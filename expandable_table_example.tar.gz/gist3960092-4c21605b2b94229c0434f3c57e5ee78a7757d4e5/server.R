library(shiny)

shinyServer(function(input, output) {
  output$plot <- reactivePlot(function() {
    plot(input$foo)
  })
})