# hflights

This dataset contains all flights departing from Houston airports IAH
(George Bush Intercontinental) and HOU (Houston Hobby) in 2011. The data comes
from the [Research and Innovation Technology Administration](http://www.transtats.bts.gov/DatabaseInfo.asp?DB_ID=120&Link=0) at the
Bureau of Transporation statistics.

Install:

* From CRAN, with `install.packages("hflights")`
* From gituhb, with `devtools::install_github("hadley/hflights")`
