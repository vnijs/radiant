##' functions for Grid graphics
##' 
##' @name gridExtra-package
##' @aliases gridExtra
##' @docType package
##' @import grid
##' @title misc. high-level functions for Grid graphics
##' @author baptiste Auguie \email{baptiste.auguie@@gmail.com}
##' @references
##' R Graphics by Paul Murrell, ggplot2 source code
##' @keywords packagelibrary
##' @seealso \code{\link{Grid}}
##' 
function()
  NULL
