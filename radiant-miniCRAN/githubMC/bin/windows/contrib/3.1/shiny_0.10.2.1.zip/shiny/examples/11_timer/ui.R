shinyUI(fluidPage(
  textOutput("currentTime")
))