library(testthat)
library(selectr)

test_package("selectr")
