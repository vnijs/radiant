`metaMDSrotate` <-
    function(object, vec, na.rm = FALSE, ...)
{
    .Deprecated(new="MDSrotate", "vegan")
    MDSrotate(object = object, vec = vec, na.rm = na.rm, ...)
}
