We can add a file upload input in the UI using the function `fileInput()`,
e.g. `fileInput('foo')`. In `server.R`, we can access the uploaded files via
`input$foo`. See [the
tutorial](http://rstudio.github.io/shiny/tutorial/#uploads) for more details.
