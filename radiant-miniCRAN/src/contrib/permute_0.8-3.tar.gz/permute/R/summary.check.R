`summary.check` <- function(object, ...)
{
    class(object) <- "summary.check"
    object
}
