`Blocks` <- function(strata = NULL) {
    out <- list(strata = strata)
    ## keep as list for now
    ##class(out) <- "Blocks"
    out
}
