#ifndef RCAIRO_BEM_H
#define RCAIRO_BEM_H

#include "backend.h"

void Rcairo_register_backend(Rcairo_backend_def* def);

#endif
