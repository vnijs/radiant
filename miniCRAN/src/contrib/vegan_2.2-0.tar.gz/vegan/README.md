# vegan: an R package for community ecologists

## Build status

Linux       | Windows
------------|------------
[![Build Status](https://travis-ci.org/vegandevs/vegan.svg?branch=master)](https://travis-ci.org/vegandevs/vegan) | [![Build status](https://ci.appveyor.com/api/projects/status/n7c2srupr55uhh4u/branch/master?svg=true)](https://ci.appveyor.com/project/gavinsimpson/vegan/branch/master)
