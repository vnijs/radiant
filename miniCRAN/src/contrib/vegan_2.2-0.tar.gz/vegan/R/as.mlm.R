`as.mlm` <-
function(x) UseMethod("as.mlm")

