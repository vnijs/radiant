`ordiArgAbsorber` <- function(..., shrink, origin, scaling, triangular,
                              display, choices, const, FUN)
    match.fun(FUN)(...)
