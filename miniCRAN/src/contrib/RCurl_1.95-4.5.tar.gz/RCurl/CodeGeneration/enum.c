#include <curl/curl.h>

CURLoption opt;
CURLformoption fopt;

